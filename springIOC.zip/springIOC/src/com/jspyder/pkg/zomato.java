package com.jspyder.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class zomato {
public static void main(String[] args) {
	
		
		ApplicationContext c = new ClassPathXmlApplicationContext("config.xml");
		
		user u= (user)c.getBean("rcb");
		
	
		System.out.println(u);
		
	
		
		
	
}
}
