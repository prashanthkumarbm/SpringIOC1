package com.jsp.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class zomato {
public static void main(String[] args) {
	
	ApplicationContext c= new ClassPathXmlApplicationContext("config.xml");
	users  u = (users)c.getBean("bulls");
	System.out.println(u);
	//System.out.println(u.getId());
	
}
}
