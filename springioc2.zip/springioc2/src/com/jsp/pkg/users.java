package com.jsp.pkg;

public class users {
private String name;
private int id;
private address workaddress;
private address homeaddress;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() 
{
	return id;
}
public void setId(int id) 
{cddddddddddddd
	this.id = id;
}
public users(String name, int id, address workaddress, address homeaddress) {
	super();
	this.name = name;
	this.id = id;
	this.workaddress = workaddress;
	this.homeaddress = homeaddress;
}
@Override

public String toString() 
{
	return "banglaore";
}


}
